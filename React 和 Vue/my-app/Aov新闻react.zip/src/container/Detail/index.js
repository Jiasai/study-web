import React,{Component} from 'react';


class Detail extends Component {
    render(){
        return(
            <React.StrictMode>
                  <div>Detail</div>
            </React.StrictMode>
        )
    }
}

export default Detail;